**Tags:**
* input

**Input Type**
* text=name 
* email=email needs an @
* password=password type text will appear as an astrics 
* select=creates a dropdown menu
* option=items on dropdown
* button=to submit
* checkbox=option to opt in
* date=choosing your date

**Tags**
* form=encompasses form object 
* div=creates organizational containers
* label=name of inputs
* fieldset=groups related elements in a form
* 
